import { getCsrfToken, signIn } from 'next-auth/react';
import { useState } from 'react';
import HCaptcha from '@hcaptcha/react-hcaptcha';

export default function Login({ csrfToken }) {
  const [token, setToken] = useState(null);

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-100">
      <div className="bg-white p-8 rounded shadow-md w-full max-w-md">
        <h2 className="text-2xl mb-6">Login to Basic Electrical</h2>
        <form method="post" action="/api/auth/callback/credentials">
          <input name="csrfToken" type="hidden" defaultValue={csrfToken} />
          <input name="email" type="email" placeholder="Email" required className="w-full mb-4 p-2 border rounded" />
          <HCaptcha sitekey={process.env.HCAPTCHA_SITE_KEY} onVerify={setToken} />
          <button
            disabled={!token}
            type="submit"
            className="w-full mt-4 py-2 bg-green-600 text-white rounded disabled:opacity-50"
          >Sign in</button>
        </form>
        <div className="mt-4 text-center">
          <button onClick={() => signIn('github')} className="mr-2">GitHub</button>
          <button onClick={() => signIn('google')} className="mr-2">Google</button>
          <button onClick={() => signIn('facebook')}>Meta</button>
        </div>
      </div>
    </div>
  );
}

export async function getServerSideProps(context) {
  return { props: { csrfToken: await getCsrfToken(context) } };
}
