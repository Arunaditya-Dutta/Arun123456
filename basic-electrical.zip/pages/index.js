import Lottie from 'react-lottie';
import animationData from '../public/animation.json';
import Link from 'next/link';

export default function Home() {
  const defaultOptions = {
    loop: true,
    autoplay: true,
    animationData,
    rendererSettings: { preserveAspectRatio: 'xMidYMid slice' },
  };

  return (
    <div className="flex flex-col items-center justify-center h-screen bg-gray-50">
      <img src="/logo.png" alt="Basic Electrical Logo" className="w-32 mb-8" />
      <Lottie options={defaultOptions} height={300} width={300} />
      <div className="mt-8">
        <Link href="/login"><a className="px-6 py-3 bg-blue-600 text-white rounded-lg">Get Started</a></Link>
      </div>
    </div>
  );
}
