import { useSession } from 'next-auth/react';
import Header from '../components/Header';
import CourseList from '../components/CourseList';
import Chatbot from '../components/Chatbot';

const courses = [
  { title: '1. Introduction Video' },
  { title: '2. About PLC' },
  { title: '3. PLC Working Principle' },
  { title: '4. Source & Sink Type Connection' },
  { title: '5. About PLC Language' },
  { title: '6. NO NC Concept' },
  { title: '7. How to Wiring PLC (Theory)' },
  { title: '8. PLC Software Use' },
  { title: '9. How to Program AND, OR, NOT Gate' },
  { title: '10. About SET/RESET' },
  { title: '11. About TIMER' },
  { title: '12. About Counter' },
  { title: '13. Project 1 - 10' },
];

export default function Dashboard() {
  const { data: session } = useSession();
  if (!session) return null;

  return (
    <div className="min-h-screen bg-gray-100">
      <Header />
      <main className="p-6">
        <h1 className="text-3xl mb-4">Welcome, {session.user.name || session.user.email}!</h1>
        <section className="mb-8">
          <h2 className="text-2xl mb-2">Resume Courses</h2>
        </section>
        <section>
          <h2 className="text-2xl mb-4">All Courses</h2>
          <CourseList courses={courses} />
        </section>
      </main>
      <Chatbot />
    </div>
  );
}
