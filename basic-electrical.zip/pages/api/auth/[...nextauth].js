import NextAuth from 'next-auth';
import CredentialsProvider from 'next-auth/providers/credentials';
import GitHubProvider from 'next-auth/providers/github';
import GoogleProvider from 'next-auth/providers/google';
import FacebookProvider from 'next-auth/providers/facebook';
import HCaptchaProvider from '@next-auth/hcaptcha-provider';

export default NextAuth({
  providers: [
    CredentialsProvider({
      name: 'Email',
      credentials: { email: { label: "Email", type: "email" } },
      async authorize(credentials) {
        const user = { id: 1, name: 'User', email: credentials.email };
        return user;
      },
    }),
    GitHubProvider({ clientId: process.env.GITHUB_ID, clientSecret: process.env.GITHUB_SECRET }),
    GoogleProvider({ clientId: process.env.GOOGLE_ID, clientSecret: process.env.GOOGLE_SECRET }),
    FacebookProvider({ clientId: process.env.FACEBOOK_ID, clientSecret: process.env.FACEBOOK_SECRET }),
    HCaptchaProvider({ secret: process.env.HCAPTCHA_SECRET }),
  ],
  session: { strategy: 'jwt' },
  callbacks: {
    async jwt({ token, user }) {
      if (user) token.user = user;
      return token;
    },
    async session({ session, token }) {
      session.user = token.user;
      return session;
    },
  },
});
