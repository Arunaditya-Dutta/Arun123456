export default function SearchBar() {
  return (
    <input
      type="text"
      placeholder="Search courses..."
      className="border rounded p-2 w-64"
    />
  );
}
