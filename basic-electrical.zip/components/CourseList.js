export default function CourseList({ courses }) {
  return (
    <ul className="space-y-4">
      {courses.map((c, idx) => (
        <li key={idx} className="p-4 border rounded bg-white">
          <h3 className="text-xl font-semibold">{c.title}</h3>
          {c.description && <p className="mt-2 text-gray-600">{c.description}</p>}
        </li>
      ))}
    </ul>
  );
}
