export default function Chatbot() {
  return <div id="pi-chatbot" className="fixed bottom-4 right-4" />;
}
