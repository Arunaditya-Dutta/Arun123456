import { useState } from 'react';
export default function AccountDropdown() {
  const [open, setOpen] = useState(false);
  return (
    <div className="relative">
      <button onClick={() => setOpen(!open)}>Account</button>
      {open && (
        <ul className="absolute right-0 mt-2 bg-white shadow rounded">
          <li className="p-2 hover:bg-gray-100">App Settings</li>
          <li className="p-2 hover:bg-gray-100">Theme (Dark/Light/Eye)</li>
          <li className="p-2 hover:bg-gray-100">Contact</li>
          <li className="p-2 hover:bg-gray-100">Rating</li>
          <li className="p-2 hover:bg-gray-100">Privacy Policy</li>
          <li className="p-2 hover:bg-gray-100">FAQ</li>
        </ul>
      )}
    </div>
  );
}
