import { Menu } from 'lucide-react';
export default function MenuButton() {
  return (
    <button aria-label="Menu">
      <Menu size={24} />
    </button>
  );
}
